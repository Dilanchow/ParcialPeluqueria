import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

// Modelo para representar los datos de una peluquería
class Peluqueria {
  final String? razonSocial;
  final String? direccionComercial;

  Peluqueria({this.razonSocial, this.direccionComercial});

  // Factory constructor para convertir un mapa (JSON) en una instancia de Peluqueria
  factory Peluqueria.fromJson(Map<String, dynamic> json) {
    return Peluqueria(
      razonSocial: json["razon_social"],
      direccionComercial: json["direccion_comercial"],
    );
  }
}

// Proveedor que maneja la obtención y almacenamiento de las peluquerías
class PeluqueriaProvider extends ChangeNotifier {
  List<Peluqueria> _peluquerias = [];
  List<Peluqueria> get peluquerias => _peluquerias;

  // Método para obtener las peluquerías desde la API
  Future<void> fetchPeluquerias() async {
    try {
      final response = await http
          .get("https://www.datos.gov.co/resource/e27n-di57.json" as Uri);

      if (response.statusCode == 200) {
        Iterable list = json.decode(response.body);
        _peluquerias = list.map((model) => Peluqueria.fromJson(model)).toList();
        notifyListeners(); // Notifica a los listeners (widgets) que los datos han sido actualizados
      } else {
        throw Exception("Fallo la conexión");
      }
    } catch (error) {
      throw Exception("Error: $error");
    }
  }
}
