import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Peluqueria',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const MyHomePage(title: 'Peluquerías'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  final String title;
  const MyHomePage({super.key, required this.title});

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  late Future<List<Peluqueria>> _listadoPeluquerias;

  // Método para obtener la lista de peluquerías desde la API
  Future<List<Peluqueria>> _getPeluquerias() async {
    final response = await http
        .get(Uri.parse("https://www.datos.gov.co/resource/e27n-di57.json"));

    if (response.statusCode == 200) {
      Iterable list = json.decode(response.body);
      // Mapea los datos JSON a objetos Peluqueria usando el constructor factory
      return list.map((model) => Peluqueria.fromJson(model)).toList();
    } else {
      throw Exception("Fallo la conexión");
    }
  }

  @override
  void initState() {
    _listadoPeluquerias =
        _getPeluquerias(); // Inicializa la lista de peluquerías
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: FutureBuilder<List<Peluqueria>>(
        future: _listadoPeluquerias,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(
                child:
                    CircularProgressIndicator()); // Muestra un indicador de carga si se está esperando la respuesta de la API
          } else if (snapshot.hasError) {
            return Center(
                child: Text(
                    "Error: ${snapshot.error}")); // Muestra un mensaje de error si la conexión falla
          } else {
            // Construye una lista desplazable con los datos de las peluquerías
            return ListView.builder(
              itemCount: snapshot.data!.length,
              itemBuilder: (context, index) {
                return Card(
                  elevation: 3,
                  margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  color: Colors.white,
                  child: ListTile(
                    leading: Icon(Icons.store,
                        color: Colors.orange), // Icono de tienda
                    title: Text(
                        snapshot.data![index].razonSocial ?? "Sin nombre",
                        style: TextStyle(fontWeight: FontWeight.bold)),
                    subtitle:
                        Text(snapshot.data![index].direccionComercial ?? ""),
                    trailing: Icon(Icons
                        .arrow_forward_ios), // Icono de flecha para indicar navegación
                  ),
                );
              },
            );
          }
        },
      ),
    );
  }
}

// Modelo para representar los datos de una peluquería
class Peluqueria {
  final String? razonSocial;
  final String? direccionComercial;

  Peluqueria({this.razonSocial, this.direccionComercial});

  // Factory constructor para convertir un mapa (JSON) en una instancia de Peluqueria
  factory Peluqueria.fromJson(Map<String, dynamic> json) {
    return Peluqueria(
      razonSocial: json["razon_social"],
      direccionComercial: json["direccion_comercial"],
    );
  }
}
